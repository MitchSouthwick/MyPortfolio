import React from 'react'

const Contact = () => (
  <section className="my-8">
    <h2 className="text-2xl font-semibold mb-2">Contact</h2>
    <p>Email: your.email@example.com</p>
  </section>
)

export default Contact
