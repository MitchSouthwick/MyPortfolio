import React from 'react'

const Header = () => (
  <header className="bg-blue-600 text-white p-6">
    <h1 className="text-3xl font-bold">Your Name</h1>
    <p className="text-lg">Web Developer | Designer | Creator</p>
  </header>
)

export default Header
