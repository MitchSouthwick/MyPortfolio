import React from 'react'

const Projects = () => (
  <section className="my-8">
    <h2 className="text-2xl font-semibold mb-2">Projects</h2>
    <ul className="list-disc list-inside">
      <li>Project 1 - A brief description</li>
      <li>Project 2 - A brief description</li>
    </ul>
  </section>
)

export default Projects
